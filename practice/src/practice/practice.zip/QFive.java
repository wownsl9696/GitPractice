package practice;

import java.util.Random;

public class QFive {

	public static void main(String[] args) {
		Random r = new Random();

		char a = 'A';

		String result = "";

		for (int i = 0; i < 10; i++) {
			int b = r.nextInt(26);
			char Ran = (char) (a + b);
			result += Ran;
		}
		System.out.println(result);

		for (int i = 0; i < 3; i++) {
			int b = r.nextInt(10);
			char Rand = result.charAt(b);
			System.out.print(Rand);
		}
	}

}
