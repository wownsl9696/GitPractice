package Day1;


interface Heal
{
	
}
interface Repairable
{
	
}

class SCV 
{
	void repair(Repairable r)
	{
		if(r instanceof Tank)
		{
			Tank t = (Tank)r;
			while(t.max != t.hp)
			{
				t.hp++;
			}
		}
	}
}
class Medic
{
	void Healing(Heal h)
	{
		
	}
}

class Tank implements Repairable
{
	int max = 100;
	int hp = 0;
}

class Marine1 implements Heal
{
	int max = 50;
	int hp = 0;
}

public class chu2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

     Tank t = new Tank();
     Marine1 m = new Marine1();
     SCV s = new SCV();
     Medic md = new Medic();
	
     s.repair(t);
     
	}

}
