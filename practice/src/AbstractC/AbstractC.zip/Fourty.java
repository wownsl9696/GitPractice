package AbstractC;

import java.util.Random;

abstract class Vehicle {

	public abstract int distance();

	public abstract int gauge();

	public void move() {

	}
}

interface Booster {

}

interface Car {

}

interface Bike {

}

interface Motocycle {

}

public class Fourty {

	public static void main(String[] args) {
		Random r = new Random();

		int turn = 0;
		while (turn == 10) {
			int nomove = r.nextInt(3) + 1;

			if (nomove == 1) {
				car = 0;
			} else if (nomove == 2) {
				bike = 0;
			} else if (nomove == 3) {
				mc = 0;
			} else {
				System.out.println("잘못된 랜덤값");
			}
			
			if(turn % 2 == 0) {
				bike += 5;
			} else if (turn % 3 == 0) {
				mc += 3;
			} else if (turn % 4 == 0) {
				car += 2;
			} else {
				move;
			}
		}

	}

}
